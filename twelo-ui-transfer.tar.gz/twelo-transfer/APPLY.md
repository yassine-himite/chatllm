# Applying the twelo.ai UI to Your LLMChat Project

This archive contains every file modified in the twelo.ai project relative to the
stock LLMChat repo. Because both projects share the same monorepo layout, the files
map 1-to-1. Follow the steps below in order inside **your other project's Shell**.

---

## Prerequisites

- Your project must be a LLMChat monorepo (Turborepo + Bun).
- You need a PostgreSQL database. On Replit you can create one via the **Database**
  tab. Once created, copy the connection string into a secret called `DATABASE_URL`.

---

## Step 1 — Upload the archive

Upload `twelo-ui-transfer.tar.gz` to the root of your other Replit project using the
"Upload file" button in the file panel.

---

## Step 2 — Extract the files

Open the **Shell** tab in your other project and run:

```bash
tar -xzf twelo-ui-transfer.tar.gz --strip-components=1 -C .
rm twelo-ui-transfer.tar.gz
```

The `--strip-components=1` removes the top-level `twelo-transfer/` folder so all
files land directly at the right paths (e.g. `apps/web/...`, `packages/...`).

> **Note on package.json files:** This archive does NOT include `apps/web/package.json`
> or `packages/ai/package.json` to avoid overwriting your dependency versions.
> After extraction, you may need to manually add any missing packages (see Step 3).

---

## Step 3 — Install dependencies

Two new packages are required by the auth system:

```bash
bun add bcryptjs nanoid
bun add -d @types/bcryptjs
```

Then reinstall everything to make sure the lockfile is consistent:

```bash
bun install
```

---

## Step 4 — Run the database migration

The auth system adds a `Session` model to Prisma. Apply the migration:

```bash
bunx prisma migrate deploy
```

If this is a fresh database (no existing migrations), run instead:

```bash
bunx prisma db push
```

---

## Step 5 — Create the admin user

There is no public registration — accounts must be created manually.
Run this once to create your admin user (replace the values):

```bash
bun -e "
import bcrypt from 'bcryptjs';
import { PrismaClient } from '@prisma/client';
const prisma = new PrismaClient();
const hash = await bcrypt.hash('YOUR_PASSWORD', 12);
const u = await prisma.user.create({ data: { email: 'you@example.com', name: 'Admin', password: hash } });
console.log('Created:', u.email);
await prisma.\$disconnect();
"
```

---

## Step 6 — Restart the application

Click **Stop** → **Run** in the Replit workflow panel, or in the Shell:

```bash
pkill -f "next dev" || true
cd apps/web && ../../node_modules/.bin/next dev -p 5000 -H 0.0.0.0
```

---

## Step 7 — Add your Azure OpenAI keys

After logging in, open **Settings → Azure API-sleutels** (the gear icon in the
sidebar) and add your Azure OpenAI key(s). Each key needs:

- A display name
- The API key
- The endpoint URL (e.g. `https://YOUR_RESOURCE.openai.azure.com/`)
- The deployment name (e.g. `gpt-4o`)

The key selector appears as a dropdown in the chat input area.

---

## What was changed

| Area | Files |
|---|---|
| **Visual / CSS** | `apps/web/app/globals.css` — brand color `#864ffe`, dark/light tokens |
| **App pages** | `apps/web/app/layout.tsx`, `chat/page.tsx`, `chat/[threadId]/page.tsx`, `sign-in/page.tsx` |
| **Auth system** | `apps/web/app/api/auth/*`, `apps/web/lib/auth.ts`, `apps/web/middleware.ts` |
| **UI components** | 18 files in `packages/common/components/` — Dutch text, brand styling |
| **Auth context** | `packages/common/context/auth-context.tsx` — replaces Clerk with custom auth |
| **Stores** | `packages/common/store/azure-keys.store.ts` — multi-key Azure selector |
| **AI workflow** | `packages/ai/workflow/` — Azure OpenAI routing, suggestions disabled |
| **DB schema** | `packages/prisma/schema.prisma` + migration — adds `Session` model |
| **Performance** | Credits bypass when KV not configured; route prefetch on home page |

---

## Possible conflicts

| File | What to check |
|---|---|
| `apps/web/package.json` | NOT included. Manually add `bcryptjs`, `nanoid`, `next-themes` if missing. |
| `packages/ai/package.json` | NOT included. Check that `openai` SDK version matches. |
| `packages/prisma/schema.prisma` | Included. If you have custom models already, merge carefully — only the `Session` model and the `sessions` relation on `User` are new. |
