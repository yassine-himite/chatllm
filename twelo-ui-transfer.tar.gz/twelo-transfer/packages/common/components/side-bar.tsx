'use client';
import { useClerk, useUser } from '@repo/common/context';
import { FullPageLoader, HistoryItem, Logo } from '@repo/common/components';
import { useRootContext } from '@repo/common/context';
import { SETTING_TABS, useAppStore, useChatStore } from '@repo/common/store';
import { Thread } from '@repo/shared/types';
import {
    Badge,
    Button,
    cn,
    DropdownMenu,
    DropdownMenuContent,
    DropdownMenuItem,
    DropdownMenuSeparator,
    DropdownMenuTrigger,
    Flex,
} from '@repo/ui';
import {
    IconArrowBarLeft,
    IconArrowBarRight,
    IconCommand,
    IconLogout,
    IconMoon,
    IconPinned,
    IconPlus,
    IconSearch,
    IconSelector,
    IconSettings,
    IconSettings2,
    IconSun,
    IconUser,
} from '@tabler/icons-react';
import { motion } from 'framer-motion';
import moment from 'moment';
import { useTheme } from 'next-themes';
import Link from 'next/link';
import { useParams, usePathname, useRouter } from 'next/navigation';

export const Sidebar = () => {
    const { threadId: currentThreadId } = useParams();
    const pathname = usePathname();
    const { setIsCommandSearchOpen } = useRootContext();
    const isChatPage = pathname === '/chat';
    const threads = useChatStore(state => state.threads);
    const pinThread = useChatStore(state => state.pinThread);
    const unpinThread = useChatStore(state => state.unpinThread);
    const sortThreads = (threads: Thread[], sortBy: 'createdAt') => {
        return [...threads].sort((a, b) => moment(b[sortBy]).diff(moment(a[sortBy])));
    };

    const { isSignedIn, user } = useUser();
    const { signOut } = useClerk();
    const clearAllThreads = useChatStore(state => state.clearAllThreads);
    const setIsSidebarOpen = useAppStore(state => state.setIsSidebarOpen);
    const isSidebarOpen = useAppStore(state => state.isSidebarOpen);
    const setIsSettingsOpen = useAppStore(state => state.setIsSettingsOpen);
    const setSettingTab = useAppStore(state => state.setSettingTab);
    const { push } = useRouter();
    const { theme, setTheme } = useTheme();

    const toggleTheme = () => {
        setTheme(theme === 'dark' ? 'light' : 'dark');
    };

    const groupedThreads: Record<string, Thread[]> = {
        today: [],
        yesterday: [],
        last7Days: [],
        last30Days: [],
        previousMonths: [],
    };

    sortThreads(threads, 'createdAt')?.forEach(thread => {
        const createdAt = moment(thread.createdAt);
        const now = moment();

        if (createdAt.isSame(now, 'day')) {
            groupedThreads.today.push(thread);
        } else if (createdAt.isSame(now.clone().subtract(1, 'day'), 'day')) {
            groupedThreads.yesterday.push(thread);
        } else if (createdAt.isAfter(now.clone().subtract(7, 'days'))) {
            groupedThreads.last7Days.push(thread);
        } else if (createdAt.isAfter(now.clone().subtract(30, 'days'))) {
            groupedThreads.last30Days.push(thread);
        } else {
            groupedThreads.previousMonths.push(thread);
        }

        //TODO: Paginate these threads
    });

    const renderGroup = ({
        title,
        threads,

        groupIcon,
        renderEmptyState,
    }: {
        title: string;
        threads: Thread[];
        groupIcon?: React.ReactNode;
        renderEmptyState?: () => React.ReactNode;
    }) => {
        if (threads.length === 0 && !renderEmptyState) return null;
        return (
            <Flex direction="col" items="start" className="w-full gap-0.5">
                <div className="text-muted-foreground/70 flex flex-row items-center gap-1 px-2 py-1 text-xs font-medium opacity-70">
                    {groupIcon}
                    {title}
                </div>
                {threads.length === 0 && renderEmptyState ? (
                    renderEmptyState()
                ) : (
                    <Flex className="border-border/50 w-full gap-0.5" gap="none" direction="col">
                        {threads.map(thread => (
                            <HistoryItem
                                thread={thread}
                                pinThread={() => pinThread(thread.id)}
                                unpinThread={() => unpinThread(thread.id)}
                                isPinned={thread.pinned}
                                key={thread.id}
                                dismiss={() => {
                                    setIsSidebarOpen(prev => false);
                                }}
                                isActive={thread.id === currentThreadId}
                            />
                        ))}
                    </Flex>
                )}
            </Flex>
        );
    };

    return (
        <div
            className={cn(
                'relative bottom-0 left-0 top-0 z-[50] flex h-[100dvh] flex-shrink-0 flex-col  py-2 transition-all duration-200',
                isSidebarOpen ? 'top-0 h-full w-[230px]' : 'w-[50px]'
            )}
        >
            <Flex direction="col" className="w-full flex-1 items-start overflow-hidden">
                <div className="mb-3 flex w-full flex-row items-center justify-between">
                    <Link href="/chat" className="w-full">
                        <motion.div
                            initial={{ opacity: 0 }}
                            animate={{ opacity: 1 }}
                            transition={{ duration: 0.3, delay: 0.2 }}
                            className={cn(
                                'flex h-8 w-full cursor-pointer items-center justify-start gap-1.5 px-4',
                                !isSidebarOpen && 'justify-center px-0'
                            )}
                        >
                            <Logo className="text-brand size-5" />
                            {isSidebarOpen && (
                                <p className="font-clash text-foreground text-lg font-bold tracking-wide">
                                    twelo.ai
                                </p>
                            )}
                        </motion.div>
                    </Link>
                    {isSidebarOpen && (
                        <Button
                            variant="ghost"
                            tooltip="Zijbalk sluiten"
                            tooltipSide="right"
                            size="icon-sm"
                            onClick={() => setIsSidebarOpen(prev => !prev)}
                            className={cn(!isSidebarOpen && 'mx-auto', 'mr-2')}
                        >
                            <IconArrowBarLeft size={16} strokeWidth={2} />
                        </Button>
                    )}
                </div>
                <Flex
                    direction="col"
                    className={cn(
                        'w-full items-end px-3 ',
                        !isSidebarOpen && 'items-center justify-center px-0'
                    )}
                    gap="xs"
                >
                    {!isChatPage ? (
                        <Link href="/chat" className={isSidebarOpen ? 'w-full' : ''}>
                            <Button
                                size={isSidebarOpen ? 'sm' : 'icon-sm'}
                                variant="bordered"
                                rounded="lg"
                                tooltip={isSidebarOpen ? undefined : 'Nieuw gesprek'}
                                tooltipSide="right"
                                className={cn(isSidebarOpen && 'relative w-full', 'justify-center')}
                            >
                                <IconPlus size={16} strokeWidth={2} className={cn(isSidebarOpen)} />
                                {isSidebarOpen && 'Nieuw'}
                            </Button>
                        </Link>
                    ) : (
                        <Button
                            size={isSidebarOpen ? 'sm' : 'icon-sm'}
                            variant="bordered"
                            rounded="lg"
                            tooltip={isSidebarOpen ? undefined : 'Nieuw gesprek'}
                            tooltipSide="right"
                            className={cn(isSidebarOpen && 'relative w-full', 'justify-center')}
                        >
                            <IconPlus size={16} strokeWidth={2} className={cn(isSidebarOpen)} />
                            {isSidebarOpen && 'Nieuw gesprek'}
                        </Button>
                    )}
                    <Button
                        size={isSidebarOpen ? 'sm' : 'icon-sm'}
                        variant="bordered"
                        rounded="lg"
                        tooltip={isSidebarOpen ? undefined : 'Zoeken'}
                        tooltipSide="right"
                        className={cn(
                            isSidebarOpen && 'relative w-full',
                            'text-muted-foreground justify-center px-2'
                        )}
                        onClick={() => setIsCommandSearchOpen(true)}
                    >
                        <IconSearch size={14} strokeWidth={2} className={cn(isSidebarOpen)} />
                        {isSidebarOpen && 'Zoeken'}
                        {isSidebarOpen && <div className="flex-1" />}
                        {isSidebarOpen && (
                            <div className="flex flex-row items-center gap-1">
                                <Badge
                                    variant="secondary"
                                    className="bg-muted-foreground/10 text-muted-foreground flex size-5 items-center justify-center rounded-md p-0"
                                >
                                    <IconCommand size={12} strokeWidth={2} className="shrink-0" />
                                </Badge>
                                <Badge
                                    variant="secondary"
                                    className="bg-muted-foreground/10 text-muted-foreground flex size-5 items-center justify-center rounded-md p-0"
                                >
                                    K
                                </Badge>
                            </div>
                        )}
                    </Button>
                </Flex>
                <Flex
                    direction="col"
                    gap="xs"
                    className={cn(
                        'border-hard mt-3 w-full  justify-center border-t border-dashed px-3 py-2',
                        !isSidebarOpen && 'items-center justify-center px-0'
                    )}
                >
                </Flex>

                {false ? (
                    <FullPageLoader />
                ) : (
                    <Flex
                        direction="col"
                        gap="md"
                        className={cn(
                            'no-scrollbar w-full flex-1 overflow-y-auto px-3 pb-[100px]',
                            isSidebarOpen ? 'flex' : 'hidden'
                        )}
                    >
                        {renderGroup({
                            title: 'Vastgezet',
                            threads: threads
                                .filter(thread => thread.pinned)
                                .sort((a, b) => b.pinnedAt.getTime() - a.pinnedAt.getTime()),
                            groupIcon: <IconPinned size={14} strokeWidth={2} />,
                            renderEmptyState: () => (
                                <div className="border-hard flex w-full flex-col items-center justify-center gap-2 rounded-lg border border-dashed p-2">
                                    <p className="text-muted-foreground text-xs opacity-50">
                                        Geen vastgezette gesprekken
                                    </p>
                                </div>
                            ),
                        })}
                        {renderGroup({ title: 'Vandaag', threads: groupedThreads.today })}
                        {renderGroup({ title: 'Gisteren', threads: groupedThreads.yesterday })}
                        {renderGroup({ title: 'Afgelopen 7 dagen', threads: groupedThreads.last7Days })}
                        {renderGroup({ title: 'Afgelopen 30 dagen', threads: groupedThreads.last30Days })}
                        {renderGroup({
                            title: 'Vorige maanden',
                            threads: groupedThreads.previousMonths,
                        })}
                    </Flex>
                )}

                <Flex
                    className={cn(
                        'from-tertiary via-tertiary/95 absolute bottom-0 mt-auto w-full items-center bg-gradient-to-t via-60% to-transparent p-2 pt-12',
                        isSidebarOpen && 'items-start justify-between'
                    )}
                    gap="xs"
                    direction={'col'}
                >
                    {!isSidebarOpen && (
                        <Button
                            variant="ghost"
                            size="icon"
                            tooltip="Zijbalk openen"
                            tooltipSide="right"
                            onClick={() => setIsSidebarOpen(prev => !prev)}
                            className={cn(!isSidebarOpen && 'mx-auto')}
                        >
                            <IconArrowBarRight size={16} strokeWidth={2} />
                        </Button>
                    )}
                    {isSignedIn && (
                        <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                                <div
                                    className={cn(
                                        'hover:bg-quaternary bg-background shadow-subtle-xs flex w-full cursor-pointer flex-row items-center gap-3 rounded-lg px-2 py-1.5',
                                        !isSidebarOpen && 'px-1.5'
                                    )}
                                >
                                    <div className="bg-brand flex size-5 shrink-0 items-center justify-center rounded-full">
                                        {user && user.hasImage ? (
                                            <img
                                                src={user?.imageUrl ?? ''}
                                                width={0}
                                                height={0}
                                                className="size-full shrink-0 rounded-full"
                                                alt={user?.fullName ?? ''}
                                            />
                                        ) : (
                                            <IconUser
                                                size={14}
                                                strokeWidth={2}
                                                className="text-background"
                                            />
                                        )}
                                    </div>

                                    {isSidebarOpen && (
                                        <p className="line-clamp-1 flex-1 !text-sm font-medium">
                                            {user?.fullName}
                                        </p>
                                    )}
                                    {isSidebarOpen && (
                                        <IconSelector
                                            size={14}
                                            strokeWidth={2}
                                            className="text-muted-foreground"
                                        />
                                    )}
                                </div>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent>
                                <DropdownMenuItem onClick={() => setIsSettingsOpen(true)}>
                                    <IconSettings size={16} strokeWidth={2} />
                                    Instellingen
                                </DropdownMenuItem>
                                {isSignedIn && (
                                    <DropdownMenuItem onClick={() => { setIsSettingsOpen(true); setSettingTab(SETTING_TABS.PROFILE); }}>
                                        <IconUser size={16} strokeWidth={2} />
                                        Profiel
                                    </DropdownMenuItem>
                                )}
                                <DropdownMenuSeparator />
                                <DropdownMenuItem onClick={toggleTheme}>
                                    {theme === 'dark' ? (
                                        <IconSun size={16} strokeWidth={2} />
                                    ) : (
                                        <IconMoon size={16} strokeWidth={2} />
                                    )}
                                    {theme === 'dark' ? 'Lichte modus' : 'Donkere modus'}
                                </DropdownMenuItem>
                                <DropdownMenuSeparator />
                                {isSignedIn && (
                                    <DropdownMenuItem onClick={() => signOut()}>
                                        <IconLogout size={16} strokeWidth={2} />
                                        Uitloggen
                                    </DropdownMenuItem>
                                )}
                            </DropdownMenuContent>
                        </DropdownMenu>
                    )}
                    {isSidebarOpen && !isSignedIn && (
                        <div className="flex w-full flex-col gap-1.5 p-1">
                            <Button
                                variant="bordered"
                                size="sm"
                                rounded="lg"
                                className="w-full"
                                onClick={() => setIsSettingsOpen(true)}
                            >
                                <IconSettings2 size={14} strokeWidth={2} />
                                Instellingen
                            </Button>
                            <Button size="sm" rounded="lg" onClick={() => push('/sign-in')}>
                                Inloggen / Registreren
                            </Button>
                        </div>
                    )}
                </Flex>
            </Flex>
        </div>
    );
};
