import { Button, ButtonProps, Popover, PopoverContent, PopoverTrigger } from '@repo/ui';
import { FC, ReactNode } from 'react';

type ConfirmPopoverProps = {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onConfirm: () => void;
  title?: string;
  confirmText?: string;
  cancelText?: string;
  confirmVariant?: ButtonProps['variant'];
  cancelVariant?: ButtonProps['variant'];
  children: ReactNode;
  additionalActions?: ReactNode;
};

export const ConfirmPopover: FC<ConfirmPopoverProps> = ({
  open,
  onOpenChange,
  onConfirm,
  title = 'Weet je het zeker?',
  confirmText = 'Verwijderen',
  cancelText = 'Annuleren',
  confirmVariant = 'destructive',
  cancelVariant = 'ghost',
  children,
  additionalActions,
}) => {
  return (
    <Popover open={open} onOpenChange={onOpenChange}>
      <PopoverTrigger asChild>{children}</PopoverTrigger>
      <PopoverContent>
        <p className="pb-2 text-sm font-medium md:text-base">{title}</p>
        <div className="flex flex-row gap-1">
          <Button
            variant={confirmVariant}
            onClick={e => {
              onConfirm();
              e.stopPropagation();
            }}
          >
            {confirmText}
          </Button>
          <Button
            variant={cancelVariant}
            onClick={e => {
              onOpenChange(false);
              e.stopPropagation();
            }}
          >
            {cancelText}
          </Button>
          {additionalActions}
        </div>
      </PopoverContent>
    </Popover>
  );
};
