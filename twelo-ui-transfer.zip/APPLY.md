# Applying the twelo.ai UI to Your LLMChat Project

This archive contains every file modified in the twelo.ai project relative to the
stock LLMChat repo. Because both projects share the same monorepo layout, the files
map 1-to-1. Follow the steps below in order inside **your other project's Shell**.

---

## Prerequisites

- Your project must be a LLMChat monorepo (Turborepo + Bun).
- You need a PostgreSQL database. On Replit you can create one via the **Database**
  tab. Once created, copy the connection string into a secret called `DATABASE_URL`.

---

## Step 1 — Upload the archive

Upload `twelo-ui-transfer.zip` to the root of your other Replit project using the
"Upload file" button in the file panel.

---

## Step 2 — Extract the files

Open the **Shell** tab in your other project and run:

```bash
unzip -o twelo-ui-transfer.zip -d .
rm twelo-ui-transfer.zip
```

The `-o` flag overwrites existing files without prompting. Files land directly at
the right paths (e.g. `apps/web/...`, `packages/...`).

> **package.json & bun.lockb:** These files ARE included. If your other project has
> different dependency versions installed, run `bun install` after extraction (Step 3)
> and resolve any version conflicts manually by checking `git diff apps/web/package.json`.

---

## Step 3 — Install dependencies

```bash
bun install
```

If `bcryptjs` or `nanoid` are missing after install, add them explicitly:

```bash
bun add bcryptjs nanoid
bun add -d @types/bcryptjs
```

---

## Step 4 — Run the database migration

The auth system adds a `Session` model to Prisma. Apply the migration:

```bash
bunx prisma migrate deploy
```

If this is a fresh database (no existing migrations), run instead:

```bash
bunx prisma db push
```

---

## Step 5 — Create the admin user

There is no public registration — accounts must be created manually.
Run this once to create your admin user (replace the values):

```bash
bun -e "
import bcrypt from 'bcryptjs';
import { PrismaClient } from '@prisma/client';
const prisma = new PrismaClient();
const hash = await bcrypt.hash('YOUR_PASSWORD', 12);
const u = await prisma.user.create({ data: { email: 'you@example.com', name: 'Admin', password: hash } });
console.log('Created:', u.email);
await prisma.\$disconnect();
"
```

---

## Step 6 — Restart the application

Click **Stop** → **Run** in the Replit workflow panel, or in the Shell:

```bash
pkill -f "next dev" || true
cd apps/web && ../../node_modules/.bin/next dev -p 5000 -H 0.0.0.0
```

---

## Step 7 — Add your Azure OpenAI keys

After logging in, open **Settings → Azure API-sleutels** (the gear icon in the
sidebar) and add your Azure OpenAI key(s). Each key needs:

- A display name
- The API key
- The endpoint URL (e.g. `https://YOUR_RESOURCE.openai.azure.com/`)
- The deployment name (e.g. `gpt-4o`)

The key selector appears as a dropdown in the chat input area.

---

## What was changed

| Area | Files |
|---|---|
| **Visual / CSS** | `apps/web/app/globals.css` — brand color `#864ffe`, dark/light tokens |
| **App pages** | `apps/web/app/layout.tsx`, `chat/page.tsx`, `chat/[threadId]/page.tsx`, `sign-in/page.tsx` |
| **Auth system** | `apps/web/app/api/auth/*`, `apps/web/lib/auth.ts`, `apps/web/middleware.ts` |
| **UI components** | 18 files in `packages/common/components/` — Dutch text, brand styling |
| **Auth context** | `packages/common/context/auth-context.tsx` — replaces Clerk with custom auth |
| **Stores** | `packages/common/store/azure-keys.store.ts` — multi-key Azure selector |
| **AI workflow** | `packages/ai/workflow/` — Azure OpenAI routing, suggestions disabled |
| **DB schema** | `packages/prisma/schema.prisma` + migration SQL — adds `Session` model |
| **Performance** | Credits bypass when KV not configured; route prefetch on home page |
| **Dependencies** | `apps/web/package.json`, `packages/ai/package.json`, `bun.lockb` |

---

## Possible conflicts

| File | What to check |
|---|---|
| `apps/web/package.json` | Included. If your other project pinned different Next.js or React versions, check for conflicts after `bun install`. |
| `packages/ai/package.json` | Included. If the `openai` SDK version differs, pin the version you need manually. |
| `packages/prisma/schema.prisma` | Included. If you have custom models, merge carefully — only the `Session` model and the `sessions` relation on `User` are new. |
| `replit.md` | Included. Contains project notes for this project — update as needed for your project. |
